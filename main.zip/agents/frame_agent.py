import cv2
import os

class FrameAgent:
    def __init__(self, fps_interval=1):
        self.fps_interval = fps_interval  # Har 1 sec me 1 frame extract karega

    def extract_frames(self, video_path: str, output_dir="temp_frames") -> list:
        """Video file se important frames/images alag karta hai."""
        os.makedirs(output_dir, exist_ok=True)
        extracted_files = []
        
        cap = cv2.VideoCapture(video_path)
        fps = int(cap.get(cv2.CAP_PROP_FPS)) or 30
        frame_rate = int(fps * self.fps_interval)
        
        count = 0
        saved_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            if count % frame_rate == 0:
                frame_filename = os.path.join(output_dir, f"frame_{saved_count}.jpg")
                cv2.imwrite(frame_filename, frame)
                extracted_files.append(frame_filename)
                saved_count += 1
                
            count += 1
            
        cap.release()
        print(f"[FrameAgent] Extracted {len(extracted_files)} frames from video.")
        return extracted_files