from PIL import Image
from PIL.ExifTags import TAGS

class MetadataAgent:
    def __init__(self):
        pass

    def extract_metadata(self, image_path: str) -> dict:
        """Image file se EXIF data aur hidden metadata nikalta hai."""
        metadata = {}
        try:
            image = Image.open(image_path)
            exif_data = image._getexif()
            
            if exif_data:
                for tag, value in exif_data.items():
                    tag_name = TAGS.get(tag, tag)
                    # Non-serializable data ko ignore karke string me convert karna
                    metadata[str(tag_name)] = str(value)
            
            metadata["dimensions"] = f"{image.width}x{image.height}"
            metadata["format"] = image.format
        except Exception as e:
            metadata["error"] = f"Failed to extract EXIF: {str(e)}"
            
        return metadata